sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.deloitte.capm.capmassignfiori.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);